import java.util.LinkedList;
import java.util.HashMap;
import java.io.IOException;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.FontMetrics;
import java.awt.event.ActionListener;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowStateListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentAdapter;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import javax.swing.AbstractAction;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JColorChooser;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.BoxLayout;
import javax.swing.JOptionPane;
import javax.swing.JSlider;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class PingPongGame extends JPanel {
    public static final int AI_STUPID = 1, AI_TYPICAL = 2, AI_VECTOR = 3;
    public static final byte BALL_TRAIL = 0, STAR_TRAIL = 1;
    public static final byte YELLOW_STAR = 0, GREEN_STAR = 1, BLUE_STAR = 2;
    public static BufferedImage yellowStar, greenStar, blueStar;
    byte ballTrailType = BALL_TRAIL;
    int fps = 60, maxPlayers = 2, ballRadius = 10, gameAIIntelligenceLevel, ballTrailAmount = 3;
    Font defaultFont = new Font("Consolas", Font.PLAIN, 20);
    double gravity = 9.8, ballSpeed, ballXComponentLowerBound = 0.1;
    private int[] ballTrailCoords;
    boolean playingWithAI, randomBallDeflection, quadraticBallMotion = false, autoResetScene = true, doBallTrailEffect = false, doRandomTrailPositions = false, doTrailParticleShrinking = false;
    Color countdownMessageColor;
    Player AIPlayer;
    Oval gameBall;
    PingPongGame cinst;
    JFrame frame;
    JButton pauseBtn;
    private WindowListener currentWindowListener;
    private boolean paused = false;
    String pausedMessage = "Game Paused!", countdownMessage = "";
    private MenuResponseStates msgboxState;
    private JFrame tempFrame;
    private long countdownTimestamp = -1;
    private int countdownTime = 0;
    public static void main(String[] args) {
        new PingPongGame();
    }
    public void createPlayerRepresentativeComponent(TemporaryPlayer newPlayerTemplate, JComponent parentComponent, JButton newPlayer, boolean playWithAI) {
        JPanel playerTemplatePanel = new JPanel();
        playerTemplatePanel.setBorder(BorderFactory.createLineBorder(Color.GREEN));
        JLabel playerDescriptor = new JLabel(newPlayerTemplate.name);
        playerDescriptor.setForeground(newPlayerTemplate.color);
        playerTemplatePanel.add(playerDescriptor);
        JButton editPlayer = new JButton("Edit...");
        editPlayer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Thread() {
                    public void run() {
                        try {
                            TemporaryPlayer editedPlayerTemplate = showCreatePlayerDialog(newPlayerTemplate.name, newPlayerTemplate.color, newPlayerTemplate.bindings);
                            playerDescriptor.setText(editedPlayerTemplate.name);
                            playerDescriptor.setForeground(editedPlayerTemplate.color);
                            newPlayerTemplate.name = editedPlayerTemplate.name;
                            newPlayerTemplate.color = editedPlayerTemplate.color;
                            newPlayerTemplate.bindings = editedPlayerTemplate.bindings;
                            editedPlayerTemplate.remove();
                            parentComponent.revalidate();
                            parentComponent.repaint();
                        } catch (InterruptedException ie) {
                            ie.printStackTrace();
                        }
                    }
                }.start();
            }
        });
        playerTemplatePanel.add(editPlayer);
        JButton removePlayer = new JButton("X");
        removePlayer.setForeground(Color.WHITE);
        removePlayer.setBackground(Color.RED);
        removePlayer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Thread() {
                    public void run() {
                        if (JOptionPane.showConfirmDialog(frame, "Are you sure you want to delete this player?", "Delete player...", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                            parentComponent.remove(playerTemplatePanel);
                            newPlayerTemplate.remove();
                            if ((parentComponent.getComponents().length - 1 < maxPlayers) || (parentComponent.getComponents().length < maxPlayers && playWithAI)) {
                                newPlayer.setEnabled(true);
                            }
                            parentComponent.revalidate();
                            parentComponent.repaint();
                        }
                    }
                }.start();
            }
        });
        //playersListContent
        playerTemplatePanel.add(removePlayer);
        newPlayerTemplate.indicatorPanel = playerTemplatePanel;
        parentComponent.add(playerTemplatePanel);
        parentComponent.revalidate();
        parentComponent.repaint();
    }
    public TemporaryPlayer showCreatePlayerDialog(String name, Color color, HashMap<KeyStroke, Integer> existingBindingsMap) throws InterruptedException {
        if (tempFrame == null) {
            tempFrame = new JFrame();
        } else {
            JOptionPane.showMessageDialog(frame, "Sorry, a window is already open. Please close it before opening another one!");
            throw new IllegalStateException("Window already open");
        }
        msgboxState = MenuResponseStates.PENDING_RESPONSE;
        tempFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        tempFrame.addWindowListener(new WindowListener() {
            public void windowDeactivated(WindowEvent e) {
            }
            public void windowActivated(WindowEvent e) {
            }
            public void windowDeiconified(WindowEvent e) {
            }
            public void windowIconified(WindowEvent e) {
            }
            public void windowClosed(WindowEvent e) {
            }
            public void windowClosing(WindowEvent e) {
                msgboxState = MenuResponseStates.CANCEL;
            }
            public void windowOpened(WindowEvent e) {
            }
        });
        tempFrame.setTitle("Create new player...");
        tempFrame.setSize(new Dimension(500, 500));
        JScrollPane scrollPane = new JScrollPane();
        JPanel panel = new JPanel();
        scrollPane.add(panel);
        scrollPane.setViewportView(panel);
        panel.setLayout(new GridBagLayout());
        tempFrame.add(scrollPane);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 0;
        JLabel greeting = new JLabel("Let's get your character set up!");
        panel.add(greeting, c);
        
        JPanel playerNamePanel = new JPanel();
        playerNamePanel.setLayout(new FlowLayout());
        c.gridy = 1;
        panel.add(playerNamePanel, c);
        
        JLabel playerNameLabel = new JLabel("Enter the player's name here:");
        playerNamePanel.add(playerNameLabel);
        JTextField playerNameInput = new JTextField();
        playerNameInput.setPreferredSize(new Dimension(100, 20));
        playerNameInput.setText(name);
        playerNamePanel.add(playerNameInput);
        
        JPanel playerColorPanel = new JPanel();
        c.gridy = 2;
        panel.add(playerColorPanel, c);
        
        JLabel playerColorLabel = new JLabel("Select the player's colour!");
        playerColorPanel.add(playerColorLabel);
        JColorChooser playerColorInput = new JColorChooser(color);
        playerColorPanel.add(playerColorInput);
        
        JPanel playerKeyBindingsPanel = new JPanel();
        c.gridy = 3;
        panel.add(playerKeyBindingsPanel, c);
        
        JLabel playerKeyBindingsLabel = new JLabel("Bind keys to a player action!");
        playerKeyBindingsPanel.add(playerKeyBindingsLabel); //Check - experimental
        playerKeyBindingsPanel.add(playerColorLabel);
        JScrollPane playerKeyBindingsList = new JScrollPane();
        playerKeyBindingsList.setPreferredSize(new Dimension(200, 150));
        playerKeyBindingsPanel.add(playerKeyBindingsList);
        JPanel keyBindingsListContent = new JPanel();
        keyBindingsListContent.setLayout(new BoxLayout(keyBindingsListContent, BoxLayout.Y_AXIS));
        playerKeyBindingsList.add(keyBindingsListContent);
        playerKeyBindingsList.setViewportView(keyBindingsListContent);
        JButton addKeyBinding = new JButton("Add a key binding!");
        addKeyBinding.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Handling a click event to create a new key binding on the user's demand
                JPanel keyBinding = new JPanel();
                keyBinding.setBorder(BorderFactory.createLineBorder(Color.BLUE));
                
                JComboBox<ComboItem<KeyStroke>> inputKey = new JComboBox<ComboItem<KeyStroke>>();
                inputKey.addItem(new ComboItem<KeyStroke>("Up key", KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("Down key", KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("Left key", KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("Right key", KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("q key", KeyStroke.getKeyStroke(KeyEvent.VK_Q, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("w key", KeyStroke.getKeyStroke(KeyEvent.VK_W, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("e key", KeyStroke.getKeyStroke(KeyEvent.VK_E, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("r key", KeyStroke.getKeyStroke(KeyEvent.VK_R, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("t key", KeyStroke.getKeyStroke(KeyEvent.VK_T, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("y key", KeyStroke.getKeyStroke(KeyEvent.VK_Y, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("u key", KeyStroke.getKeyStroke(KeyEvent.VK_U, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("i key", KeyStroke.getKeyStroke(KeyEvent.VK_I, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("o key", KeyStroke.getKeyStroke(KeyEvent.VK_O, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("p key", KeyStroke.getKeyStroke(KeyEvent.VK_P, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("a key", KeyStroke.getKeyStroke(KeyEvent.VK_A, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("s key", KeyStroke.getKeyStroke(KeyEvent.VK_S, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("d key", KeyStroke.getKeyStroke(KeyEvent.VK_D, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("f key", KeyStroke.getKeyStroke(KeyEvent.VK_F, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("g key", KeyStroke.getKeyStroke(KeyEvent.VK_G, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("h key", KeyStroke.getKeyStroke(KeyEvent.VK_H, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("j key", KeyStroke.getKeyStroke(KeyEvent.VK_J, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("k key", KeyStroke.getKeyStroke(KeyEvent.VK_K, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("l key", KeyStroke.getKeyStroke(KeyEvent.VK_L, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("z key", KeyStroke.getKeyStroke(KeyEvent.VK_Z, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("x key", KeyStroke.getKeyStroke(KeyEvent.VK_X, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("c key", KeyStroke.getKeyStroke(KeyEvent.VK_C, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("v key", KeyStroke.getKeyStroke(KeyEvent.VK_V, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("b key", KeyStroke.getKeyStroke(KeyEvent.VK_B, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("n key", KeyStroke.getKeyStroke(KeyEvent.VK_N, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("m key", KeyStroke.getKeyStroke(KeyEvent.VK_M, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("1 key", KeyStroke.getKeyStroke(KeyEvent.VK_1, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("2 key", KeyStroke.getKeyStroke(KeyEvent.VK_2, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("3 key", KeyStroke.getKeyStroke(KeyEvent.VK_3, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("4 key", KeyStroke.getKeyStroke(KeyEvent.VK_4, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("5 key", KeyStroke.getKeyStroke(KeyEvent.VK_5, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("6 key", KeyStroke.getKeyStroke(KeyEvent.VK_6, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("7 key", KeyStroke.getKeyStroke(KeyEvent.VK_7, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("8 key", KeyStroke.getKeyStroke(KeyEvent.VK_8, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("9 key", KeyStroke.getKeyStroke(KeyEvent.VK_9, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("0 key", KeyStroke.getKeyStroke(KeyEvent.VK_0, 0)));
                keyBinding.add(inputKey);
                
                JComboBox<ComboItem<Integer>> outputAction = new JComboBox<ComboItem<Integer>>();
                outputAction.addItem(new ComboItem<Integer>("Move up", Player.UP));
                outputAction.addItem(new ComboItem<Integer>("Move down", Player.DOWN));
                keyBinding.add(outputAction);
                
                JButton delete = new JButton("X");
                delete.setForeground(new Color(255, 255, 255, 255));
                delete.setBackground(new Color(255, 0, 0, 255));
                delete.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        keyBindingsListContent.remove(keyBinding);
                        keyBindingsListContent.revalidate();
                        keyBindingsListContent.repaint();
                    }
                });
                keyBinding.add(delete);
                keyBindingsListContent.add(keyBinding, 1);
                keyBindingsListContent.revalidate();
                keyBindingsListContent.repaint();
            }
        });
        keyBindingsListContent.add(addKeyBinding);
        
        if (existingBindingsMap != null) {
            //Iteratively adding any prespecified key bindings (in parameter existingBindingsMap)
            for (KeyStroke s : existingBindingsMap.keySet()) {
                JPanel keyBinding = new JPanel();
                keyBinding.setBorder(BorderFactory.createLineBorder(Color.BLUE));
                
                JComboBox<ComboItem<KeyStroke>> inputKey = new JComboBox<ComboItem<KeyStroke>>();
                inputKey.addItem(new ComboItem<KeyStroke>("Up key", KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("Down key", KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("Left key", KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("Right key", KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("q key", KeyStroke.getKeyStroke(KeyEvent.VK_Q, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("w key", KeyStroke.getKeyStroke(KeyEvent.VK_W, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("e key", KeyStroke.getKeyStroke(KeyEvent.VK_E, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("r key", KeyStroke.getKeyStroke(KeyEvent.VK_R, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("t key", KeyStroke.getKeyStroke(KeyEvent.VK_T, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("y key", KeyStroke.getKeyStroke(KeyEvent.VK_Y, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("u key", KeyStroke.getKeyStroke(KeyEvent.VK_U, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("i key", KeyStroke.getKeyStroke(KeyEvent.VK_I, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("o key", KeyStroke.getKeyStroke(KeyEvent.VK_O, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("p key", KeyStroke.getKeyStroke(KeyEvent.VK_P, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("a key", KeyStroke.getKeyStroke(KeyEvent.VK_A, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("s key", KeyStroke.getKeyStroke(KeyEvent.VK_S, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("d key", KeyStroke.getKeyStroke(KeyEvent.VK_D, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("f key", KeyStroke.getKeyStroke(KeyEvent.VK_F, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("g key", KeyStroke.getKeyStroke(KeyEvent.VK_G, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("h key", KeyStroke.getKeyStroke(KeyEvent.VK_H, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("j key", KeyStroke.getKeyStroke(KeyEvent.VK_J, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("k key", KeyStroke.getKeyStroke(KeyEvent.VK_K, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("l key", KeyStroke.getKeyStroke(KeyEvent.VK_L, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("z key", KeyStroke.getKeyStroke(KeyEvent.VK_Z, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("x key", KeyStroke.getKeyStroke(KeyEvent.VK_X, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("c key", KeyStroke.getKeyStroke(KeyEvent.VK_C, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("v key", KeyStroke.getKeyStroke(KeyEvent.VK_V, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("b key", KeyStroke.getKeyStroke(KeyEvent.VK_B, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("n key", KeyStroke.getKeyStroke(KeyEvent.VK_N, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("m key", KeyStroke.getKeyStroke(KeyEvent.VK_M, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("1 key", KeyStroke.getKeyStroke(KeyEvent.VK_1, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("2 key", KeyStroke.getKeyStroke(KeyEvent.VK_2, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("3 key", KeyStroke.getKeyStroke(KeyEvent.VK_3, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("4 key", KeyStroke.getKeyStroke(KeyEvent.VK_4, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("5 key", KeyStroke.getKeyStroke(KeyEvent.VK_5, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("6 key", KeyStroke.getKeyStroke(KeyEvent.VK_6, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("7 key", KeyStroke.getKeyStroke(KeyEvent.VK_7, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("8 key", KeyStroke.getKeyStroke(KeyEvent.VK_8, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("9 key", KeyStroke.getKeyStroke(KeyEvent.VK_9, 0)));
                inputKey.addItem(new ComboItem<KeyStroke>("0 key", KeyStroke.getKeyStroke(KeyEvent.VK_0, 0)));
                inputKey.setSelectedItem(new ComboItem<KeyStroke>(null, s));
                keyBinding.add(inputKey);

                JComboBox<ComboItem<Integer>> outputAction = new JComboBox<ComboItem<Integer>>();
                outputAction.addItem(new ComboItem<Integer>("Move up", Player.UP));
                outputAction.addItem(new ComboItem<Integer>("Move down", Player.DOWN));
                outputAction.setSelectedItem(new ComboItem<Integer>(null, existingBindingsMap.get(s)));
                keyBinding.add(outputAction);
                
                
                JButton delete = new JButton("X");
                delete.setForeground(new Color(255, 255, 255, 255));
                delete.setBackground(new Color(255, 0, 0, 255));
                delete.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        keyBindingsListContent.remove(keyBinding);
                        keyBindingsListContent.revalidate();
                        keyBindingsListContent.repaint();
                    }
                });
                keyBinding.add(delete);
                keyBindingsListContent.add(keyBinding, 1);
                keyBindingsListContent.revalidate();
                keyBindingsListContent.repaint();
            }
        }

        JPanel OKCancelPanel = new JPanel();
        c.gridx = 2;
        c.gridy = 4;
        panel.add(OKCancelPanel, c);
                
        JButton OKButton = new JButton("OK");
        OKButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                msgboxState = MenuResponseStates.OK;
            }
        });
        OKCancelPanel.add(OKButton);
        JButton CancelButton = new JButton("Cancel");
        CancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                msgboxState = MenuResponseStates.CANCEL;
            }
        });
        OKCancelPanel.add(CancelButton);
        
        tempFrame.setVisible(true);
        while (msgboxState == MenuResponseStates.PENDING_RESPONSE) {
            Thread.sleep(50);
        }
        tempFrame.dispose();
        tempFrame = null;
        if (msgboxState == MenuResponseStates.OK) {
            HashMap<KeyStroke, Integer> bindingMap = new HashMap<KeyStroke, Integer>();
            java.awt.Component[] bindingComponents = keyBindingsListContent.getComponents();
            JPanel bindingPanel;
            for (int i = 1; i < bindingComponents.length; i++) {
                bindingPanel = (JPanel) bindingComponents[i];
                java.awt.Component[] bindingComponentChildren = bindingPanel.getComponents();
                bindingMap.put(((ComboItem<KeyStroke>) ((JComboBox) bindingComponentChildren[0]).getSelectedItem()).value, ((ComboItem<Integer>) ((JComboBox) bindingComponentChildren[1]).getSelectedItem()).value);
            }
            return new TemporaryPlayer(playerNameInput.getText(), bindingMap, playerColorInput.getColor(), this);
        } else if (msgboxState == MenuResponseStates.CANCEL) {
            throw new SecurityException("Operation cancelled by user");
        }
        /*HashMap<String, JComponent> compsMap = new HashMap<String, JComponent>();
        compsMap.put("name", playerNameInput);
        compsMap.put("color", playerColorInput);
        compsMap.put("keybindings", keyBindingsListContent);
        compsMap.put("ok", OKButton);
        return compsMap;*/
        return null;
    }
    public void displayAdvancedSettings() {
        //Wednesday 28th June 2023 13:47 - Peace at last!
        if (tempFrame == null) {
            tempFrame = new JFrame();
        } else {
            JOptionPane.showMessageDialog(frame, "Sorry, a window is already open. Please close it before opening another one!");
            throw new IllegalStateException("Window already open");
        }
        msgboxState = MenuResponseStates.PENDING_RESPONSE;
        tempFrame.setTitle("Advanced Game Settings");
        tempFrame.setSize(500, 500);
        tempFrame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        tempFrame.addWindowListener(new WindowListener() {
            public void windowDeactivated(WindowEvent e) {
            }
            public void windowActivated(WindowEvent e) {
            }
            public void windowDeiconified(WindowEvent e) {
            }
            public void windowIconified(WindowEvent e) {
            }
            public void windowClosed(WindowEvent e) {
            }
            public void windowClosing(WindowEvent e) {
                msgboxState = MenuResponseStates.CANCEL;
            }
            public void windowOpened(WindowEvent e) {
            }
        });
        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());
        tempFrame.add(mainPanel);
        
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 1;
        
        JPanel ballSettings = new JPanel();
        ballSettings.setLayout(new BoxLayout(ballSettings, BoxLayout.PAGE_AXIS));
        mainPanel.add(ballSettings, c);
        
        JCheckBox quadraticMotion = new JCheckBox("Quadratic ball motion (bouncy-bounce):");
        quadraticMotion.setSelected(quadraticBallMotion);
        ballSettings.add(quadraticMotion);
        
        JTextField ballXVelocityLowerBound = new JTextField();

        JCheckBox ballStuckResetScene = new JCheckBox("Automatically reset scene if ball is stuck:");
        ballStuckResetScene.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                ballXVelocityLowerBound.setEnabled(ballStuckResetScene.isSelected());
            }
        });
        ballStuckResetScene.setSelected(autoResetScene);
        ballSettings.add(ballStuckResetScene);
        
        JPanel velocityBoundsPanel = new JPanel();
        ballSettings.add(velocityBoundsPanel);
        
        JLabel XLowerBoundVelocityLabel = new JLabel("Minimum ball X-component to reset scene (somewhat low or zero positive value recommended)");
        velocityBoundsPanel.add(XLowerBoundVelocityLabel);
        ballXVelocityLowerBound.setText(Double.toString(ballXComponentLowerBound));
        ballXVelocityLowerBound.setPreferredSize(new Dimension(50, 20));
        velocityBoundsPanel.add(ballXVelocityLowerBound);

        
        JPanel effectsPanel = new JPanel();
        effectsPanel.setLayout(new BoxLayout(effectsPanel, BoxLayout.PAGE_AXIS));
        c.gridy = 2;
        mainPanel.add(effectsPanel, c);

        JPanel ballTrailCountPanel = new JPanel();

        JLabel ballTrailCountLabel = new JLabel("Number of objects trailing behind original:");
        ballTrailCountPanel.add(ballTrailCountLabel);

        JTextField objectTrailCountTextField = new JTextField();
        objectTrailCountTextField.setText(Integer.toString(ballTrailAmount));
        objectTrailCountTextField.setPreferredSize(new Dimension(50, 20));
        ballTrailCountPanel.add(objectTrailCountTextField);

        JCheckBox randomisedTrailCheckBox = new JCheckBox("Randomise trail particles' position: ");
        randomisedTrailCheckBox.setSelected(doRandomTrailPositions);

        JCheckBox shrinkTrailParticlesCheckBox = new JCheckBox("Shrink trail particles as they age: ");
        shrinkTrailParticlesCheckBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //Singular '&' character intentional - short-circuit 'if' statement to avoid unnecessarily querying the user
                if (shrinkTrailParticlesCheckBox.isSelected()) {
                    if (JOptionPane.showConfirmDialog(tempFrame, "Dynamically shrinking each and every particle during gameplay is somewhat resource-intensive and can possibly result in poor game performance and unpleasant problems, such as a noticeable frame rate drop. Are you sure you want to continue?", "PERFORMANCE WARNING: Dynamically shrinking particles", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == JOptionPane.NO_OPTION) {
                        shrinkTrailParticlesCheckBox.setSelected(false);
                    }
                }
            }
        });
        shrinkTrailParticlesCheckBox.setSelected(doTrailParticleShrinking);

        JComboBox<ComboItem<Byte>> trailTypeSelector = new JComboBox<ComboItem<Byte>>();
        trailTypeSelector.addItem(new ComboItem<Byte>("Standard ball trail", BALL_TRAIL));
        trailTypeSelector.addItem(new ComboItem<Byte>("Star trail", STAR_TRAIL));
        trailTypeSelector.setSelectedItem(new ComboItem<Byte>(null, ballTrailType));
        ActionListener trailTypeSelectorChangeHandler = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                randomisedTrailCheckBox.setEnabled(!((ComboItem<Byte>) (trailTypeSelector.getSelectedItem())).value.equals(BALL_TRAIL));
            }
        };
        trailTypeSelector.addActionListener(trailTypeSelectorChangeHandler);
        trailTypeSelectorChangeHandler.actionPerformed(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null));

        JCheckBox trailBlurSelectorCheckbox = new JCheckBox("Enable ball trail effect (WARNING: CAN CAUSE PERFORMANCE DROP)");
        trailBlurSelectorCheckbox.setSelected(doBallTrailEffect);
        ChangeListener blurSelectorListener = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                randomisedTrailCheckBox.setEnabled(trailBlurSelectorCheckbox.isSelected() && !((ComboItem<Byte>) (trailTypeSelector.getSelectedItem())).value.equals(BALL_TRAIL));
                shrinkTrailParticlesCheckBox.setEnabled(trailBlurSelectorCheckbox.isSelected());
                objectTrailCountTextField.setEnabled(trailBlurSelectorCheckbox.isSelected());
                trailTypeSelector.setEnabled(trailBlurSelectorCheckbox.isSelected());
            }
        };
        trailBlurSelectorCheckbox.addChangeListener(blurSelectorListener);
        effectsPanel.add(trailBlurSelectorCheckbox);
        effectsPanel.add(ballTrailCountPanel);
        //Trigger change listener for the first time
        blurSelectorListener.stateChanged(new ChangeEvent(new Object()));

        JPanel trailPropertiesPanel = new JPanel();

        JLabel trailTypeLabel = new JLabel("Select type of trail behind the ball: ");
        trailPropertiesPanel.add(trailTypeLabel);
        trailPropertiesPanel.add(trailTypeSelector);
        trailPropertiesPanel.add(randomisedTrailCheckBox);
        trailPropertiesPanel.add(shrinkTrailParticlesCheckBox);

        effectsPanel.add(trailPropertiesPanel);

        JPanel OKCancelPanel = new JPanel();
        c.gridx = 1;
        c.gridy = 3;
        mainPanel.add(OKCancelPanel, c);
                
        JButton OKButton = new JButton("OK");
        OKButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (ballStuckResetScene.isSelected()) {
                    try {
                        double lboundValue = Double.parseDouble(ballXVelocityLowerBound.getText());
                        if (lboundValue < 0 || lboundValue == Double.POSITIVE_INFINITY || Double.isNaN(lboundValue)) {
                            JOptionPane.showMessageDialog(tempFrame, "The lower bound for the ball's X component MUST be a FINITE and POSITIVE number LOWER THAN THE BALL'S SPEED! (Decimal numbers allowed)");
                            return;
                        } else {
                            if (lboundValue > 1.0) {
                                if (JOptionPane.showConfirmDialog(tempFrame, "The lower bound of x-velocity you have specified is quite high. While your input is perfectly logical, it can result in possibly excessive and unnecessary scene resetting. Are you sure you want to continue?", "WARNING: High x-component lower bound", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) != JOptionPane.YES_OPTION) {
                                    return;
                                }
                            }
                        }
                    } catch (NumberFormatException nfe) {
                        JOptionPane.showMessageDialog(tempFrame, "The lower bound for the ball's X component MUST be a finite and positive NUMBER! (Decimal numbers allowed)");
                        return;
                    }
                }
                if (trailBlurSelectorCheckbox.isSelected()) {
                    try {
                        int numTrailingObjects = Integer.parseInt(objectTrailCountTextField.getText());
                        if (numTrailingObjects < 0 || numTrailingObjects == Double.POSITIVE_INFINITY || Double.isNaN(numTrailingObjects)) {
                            JOptionPane.showMessageDialog(tempFrame, "The amount of balls in the trail MUST be a FINITE and POSITIVE integer, preferably above zero! (Decimal numbers NOT allowed)");
                            return;
                        } else if (numTrailingObjects > 100) {
                            if (JOptionPane.showConfirmDialog(tempFrame, "The number of trailing objects you desire (" + numTrailingObjects + ") is very high. This can possibly result in various performance issues during gameplay, such low game FPS. Are you sure you want to continue?", "PERFORMANCE WARNING: High number of trailing balls", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) != JOptionPane.YES_OPTION) {
                                return;
                            }
                        }
                    } catch (NumberFormatException nfe) {
                        JOptionPane.showMessageDialog(tempFrame, "The amount of objects in the trail MUST be a finite and positive INTEGER! (Decimal numbers NOT allowed)");
                        return;
                    }
                }
                msgboxState = MenuResponseStates.OK;
            }
        });
        OKCancelPanel.add(OKButton);
        JButton CancelButton = new JButton("Cancel");
        CancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                msgboxState = MenuResponseStates.CANCEL;
            }
        });
        OKCancelPanel.add(CancelButton);


        tempFrame.pack();
        tempFrame.setVisible(true);
        while (msgboxState == MenuResponseStates.PENDING_RESPONSE) {
            try {
                Thread.sleep(50);
            } catch (InterruptedException ie) {
                ie.printStackTrace();
            }
        }
        tempFrame.dispose();
        tempFrame = null;
        if (msgboxState == MenuResponseStates.OK) {
            quadraticBallMotion = quadraticMotion.isSelected();
            autoResetScene = ballStuckResetScene.isSelected();
            ballXComponentLowerBound = Double.parseDouble(ballXVelocityLowerBound.getText());
            doBallTrailEffect = trailBlurSelectorCheckbox.isSelected();
            ballTrailAmount = Integer.parseInt(objectTrailCountTextField.getText());
            ballTrailType = ((ComboItem<Byte>) trailTypeSelector.getSelectedItem()).value;
            doRandomTrailPositions = randomisedTrailCheckBox.isSelected();
            doTrailParticleShrinking = shrinkTrailParticlesCheckBox.isSelected();
        } else if (msgboxState == MenuResponseStates.CANCEL) {
            throw new SecurityException("Operation cancelled by user");
        }
    }
    public void displayMenu() {
        frame = new JFrame();
        frame.setTitle("Ping-pong game");
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        currentWindowListener = new WindowListener() {
            public void windowDeactivated(WindowEvent e) {
            }
            public void windowActivated(WindowEvent e) {
            }
            public void windowDeiconified(WindowEvent e) {
            }
            public void windowIconified(WindowEvent e) {
            }
            public void windowClosed(WindowEvent e) {
            }
            public void windowClosing(WindowEvent e) {
                //Free all resources
                if (tempFrame != null) {
                    tempFrame.dispose();
                }
                frame.dispose();
            }
            public void windowOpened(WindowEvent e) {
            }
        };
        frame.addWindowListener(currentWindowListener);

        JPanel panel = new JPanel(new GridBagLayout());
        JScrollPane initScrollPane = new JScrollPane();
        initScrollPane.add(panel);
        initScrollPane.setViewportView(panel);
        frame.add(initScrollPane);
        frame.setSize(new Dimension(500, 500));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 0;
        
        JLabel greetingLabel = new JLabel("Hey buddy! Welcome to this super-cool out-of-this-world ping-pong game! Let's get you set up!");
        panel.add(greetingLabel, c);
        
        JPanel playersListPanel = new JPanel();
        c.gridy = 1;
        playersListPanel.setPreferredSize(new Dimension(360, 130));
        panel.add(playersListPanel, c);
        JLabel playersLabel = new JLabel("Below are the players and their names! What will your name be?");
        JScrollPane playersList = new JScrollPane();
        playersList.setPreferredSize(new Dimension(150, 100));
        JPanel playersListContent = new JPanel();
        playersListContent.setLayout(new BoxLayout(playersListContent, BoxLayout.Y_AXIS));
        playersList.add(playersListContent);
        playersList.setViewportView(playersListContent);
        
        //Declare before newPlayer to put it in anonymous inner class scope for it is needed there
        JCheckBox playWithAISelector = new JCheckBox("Play against Larry the AI?");
        
        JButton newPlayer = new JButton("Add new player...");
        newPlayer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (playersListContent.getComponents().length - 1 >= maxPlayers) {
                    JOptionPane.showMessageDialog(frame, "Sorry, the maximum amount of players, " + maxPlayers + ", has been reached.");
                } else {
                    new Thread() { /*This method is synchronous - it hangs the thread it runs on - DO NOT INVOKE IT ON THE AWT PAINTING THREAD FOR GOODNESS' SAKE!!!*/
                        public void run() {
                            try {
                                TemporaryPlayer newPlayerTemplate = showCreatePlayerDialog("", new Color(0, 0, 0), null);
                                createPlayerRepresentativeComponent(newPlayerTemplate, playersListContent, newPlayer, playWithAISelector.isSelected());
                                if ((playersListContent.getComponents().length - 1 >= maxPlayers) || (playersListContent.getComponents().length >= maxPlayers && playWithAISelector.isSelected())) {
                                    newPlayer.setEnabled(false);
                                }
                            } catch (InterruptedException ie) {
                                ie.printStackTrace();
                            }
                        }
                    }.start();
                }
            }
        });
        playersListContent.add(newPlayer);
        playersListPanel.add(playersLabel);
        playersListPanel.add(playersList);

        JPanel ballColorChooserPanel = new JPanel();
        ballColorChooserPanel.setLayout(new FlowLayout());
        c.gridy = 2;
        panel.add(ballColorChooserPanel, c);
        
        JLabel ballColorChooserLabel = new JLabel("Choose the desired ball colour!");
        ballColorChooserPanel.add(ballColorChooserLabel);
        JColorChooser ballColorChooserInput = new JColorChooser(new Color(255, 0, 0));
        ballColorChooserPanel.add(ballColorChooserInput);
        
        JPanel ballSpeedChooserPanel = new JPanel();
        ballSpeedChooserPanel.setLayout(new FlowLayout());
        c.gridy = 3;
        panel.add(ballSpeedChooserPanel, c);
        
        JLabel ballSpeedChooserLabel = new JLabel("Enter the desired ball speed!");
        ballSpeedChooserPanel.add(ballSpeedChooserLabel);
        JTextField ballSpeedChooserInput = new JTextField("10");
        ballSpeedChooserInput.setPreferredSize(new Dimension(50, 20));
        ballSpeedChooserPanel.add(ballSpeedChooserInput);
        JCheckBox randomDeflection = new JCheckBox("Ball deflects randomly?");
        randomDeflection.setSelected(true);
        ballSpeedChooserPanel.add(randomDeflection);
        
        JPanel playerSpeedChooserPanel = new JPanel();
        playerSpeedChooserPanel.setLayout(new FlowLayout());
        c.gridy = 4;
        panel.add(playerSpeedChooserPanel, c);
        
        JLabel playerSpeedChooserLabel = new JLabel("Enter the desired player speed!");
        playerSpeedChooserPanel.add(playerSpeedChooserLabel);
        JTextField playerSpeedChooserInput = new JTextField("10");
        playerSpeedChooserInput.setPreferredSize(new Dimension(50, 20));
        playerSpeedChooserPanel.add(playerSpeedChooserInput);
        
        JPanel playWithAIPanel = new JPanel();
        playWithAIPanel.setLayout(new BoxLayout(playWithAIPanel, BoxLayout.PAGE_AXIS));
        c.gridy = 5;
        panel.add(playWithAIPanel, c);

        
        playWithAISelector.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                if (playWithAISelector.isSelected()) {
                    if (playersListContent.getComponents().length - 1 >= maxPlayers) {
                        JOptionPane.showMessageDialog(frame, "Sorry, the maximum amount of players, " + maxPlayers + ", has been reached.\nPlease remove a player if you would like to play against the AI");
                        playWithAISelector.setSelected(false);
                    } else if ((playersListContent.getComponents().length >= maxPlayers)) {
                        newPlayer.setEnabled(false);
                    }
                } else {
                    if ((playersListContent.getComponents().length - 1 < maxPlayers)) {
                        newPlayer.setEnabled(true);
                    } else if ((playersListContent.getComponents().length - 1 >= maxPlayers)) {
                        newPlayer.setEnabled(false);
                    }
                }
            }
        });
        playWithAIPanel.add(playWithAISelector);
        
        //Put this and the playWithAIPanel in a JScroller
        JPanel AIIntelligencePanel = new JPanel();
        playWithAIPanel.add(AIIntelligencePanel);
        JLabel AIIntelligenceLabel = new JLabel("AI Intelligence level:");
        AIIntelligencePanel.add(AIIntelligenceLabel);
        JLabel selectedAIIntelligence = new JLabel();
        JSlider AIIntelligenceLevel = new JSlider(JSlider.HORIZONTAL, 1, 3, 2);
        AIIntelligenceLevel.setMajorTickSpacing(1);
        AIIntelligenceLevel.setPaintTicks(true);
        AIIntelligenceLevel.setPaintLabels(true);
        ChangeListener AISliderListener = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                switch (AIIntelligenceLevel.getValue()) {
                    case 1:
                        selectedAIIntelligence.setForeground(Color.GREEN);
                        selectedAIIntelligence.setText("Patrick Star-level AI");
                        gameAIIntelligenceLevel = AI_STUPID;
                        break;
                    case 2:
                        selectedAIIntelligence.setForeground(Color.BLUE);
                        selectedAIIntelligence.setText("Your typical AI");
                        gameAIIntelligenceLevel = AI_TYPICAL;
                        break;
                    case 3:
                        selectedAIIntelligence.setForeground(Color.RED);
                        selectedAIIntelligence.setText("Dr. Nefario level vector-crunching AI");
                        gameAIIntelligenceLevel = AI_VECTOR;
                        break;
                    default:
                        selectedAIIntelligence.setForeground(Color.BLACK);
                        selectedAIIntelligence.setText("<Unknown>");
                }
            }
        };
        AIIntelligenceLevel.addChangeListener(AISliderListener);
        AIIntelligencePanel.add(AIIntelligenceLevel);
        playWithAIPanel.add(selectedAIIntelligence);
        //Set initial value of AI intelligence level label by programmatically invoking overriden method representing change of component state
        AISliderListener.stateChanged(new ChangeEvent(this));
        
        JButton advancedSettings = new JButton("Open Advanced Settings...");
        advancedSettings.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Thread() {
                    @Override
                    public void run() {
                        displayAdvancedSettings();
                    }
                }.start();
            }
        });
        c.gridx = 2;
        c.gridy = 6;
        panel.add(advancedSettings, c);
        
        JButton startGame = new JButton("Play!");
        startGame.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int ballSpeed, playerSpeed;
                if ((playWithAISelector.isSelected() && playersListContent.getComponents().length - 1 < 1) || (!playWithAISelector.isSelected() && playersListContent.getComponents().length - 1 <= 1)) {
                    JOptionPane.showMessageDialog(frame, "Sorry, at least two players (AI included) are required to play!");
                    return;
                }
                try {
                    ballSpeed = Integer.parseInt(ballSpeedChooserInput.getText());
                    if (ballSpeed < 1 || ballSpeed > 1000) {
                        JOptionPane.showMessageDialog(frame, "The field specifying the ball speed must be a positive integer between 1 and 1,000!");
                        return;
                    }
                } catch (NumberFormatException nfe) {
                    if (ballSpeedChooserInput.getText().length() == 0) {
                        JOptionPane.showMessageDialog(frame, "The field specifying the ball speed is mandatory - it MUST be filled in!");
                    } else {
                        JOptionPane.showMessageDialog(frame, "The field specifying the ball speed must be a positive integer between 1 and 1,000!");
                    }
                    return;
                }
                if (ballXComponentLowerBound >= ballSpeed) {
                    JOptionPane.showMessageDialog(frame, "The lowest accepted x-component of the ball must not exceed its speed (Check advanced settings)");
                    return;
                }
                try {
                    playerSpeed = Integer.parseInt(playerSpeedChooserInput.getText());
                    if (playerSpeed < 1 || playerSpeed > 1000) {
                        JOptionPane.showMessageDialog(frame, "The field specifying the player speed must be a positive integer between 1 and 1,000!");
                        return;
                    }
                } catch (NumberFormatException nfe) {
                    if (playerSpeedChooserInput.getText().length() == 0) {
                        JOptionPane.showMessageDialog(frame, "The field specifying the player speed is mandatory - it MUST be filled in!");
                    } else {
                        JOptionPane.showMessageDialog(frame, "The field specifying the player speed must be a positive integer between 1 and 1,000!");
                    }
                    return;
                }
                new Thread() {
                    @Override
                    public void run() {
                        startPlaying(ballSpeed, playerSpeed, playWithAISelector.isSelected(), randomDeflection.isSelected(), ballColorChooserInput.getColor());
                    }
                }.start();
            }
        });
        c.gridx = 1;
        panel.add(startGame, c);

        frame.pack();
        frame.setVisible(true);

        //Load default player
        HashMap<KeyStroke, Integer> defaultTemplateKeyBindings = new HashMap<KeyStroke, Integer>();
        defaultTemplateKeyBindings.put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), Player.UP);
        defaultTemplateKeyBindings.put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), Player.DOWN);
        TemporaryPlayer defaultTemplate = new TemporaryPlayer("Player 1", defaultTemplateKeyBindings, new Color(0, 0, 0), this);
        createPlayerRepresentativeComponent(defaultTemplate, playersListContent, newPlayer, playWithAISelector.isSelected());
        if ((playersListContent.getComponents().length - 1 >= maxPlayers) || (playersListContent.getComponents().length >= maxPlayers && playWithAISelector.isSelected())) {
            newPlayer.setEnabled(false);
        }
    }
    public PingPongGame() {
        cinst = this;
        displayMenu();
    }
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        FontMetrics fm;
        Graphics2D g2d = (Graphics2D) g;
        g2d.setFont(defaultFont);
        for (PhysicalObject o : PhysicalObject.getRegisteredObjects()) {
            g2d.setColor(o.color);
            if (o instanceof Oval) {
                Oval oval = (Oval) o;
                //Draw ball trail effect if applicable
                if (o == gameBall && doBallTrailEffect) {
                    for (int i = 0; i < ballTrailCoords.length; i += 3) {
                        //Get type of particle from data int ((3 * n + 2)th index of array)
                        if (ballTrailCoords[i + 2]/16777216 == 0/*2^(8*3) = 16777216 -> mathematically getting the contents of the very first byte of an int*/) {
                            //Typical ball trail
                            g2d.setColor(new Color(o.color.getRed(), o.color.getGreen(), o.color.getBlue(), (int) (255.0 * i/(ballTrailCoords.length * 2))));
                            if (doTrailParticleShrinking) {
                                g2d.fillOval((int) ballTrailCoords[i], (int) ballTrailCoords[i + 1], (int) (o.width * ((double) i)/ballTrailCoords.length), (int) (o.height * ((double) i)/ballTrailCoords.length));
                            } else {
                                g2d.fillOval((int) ballTrailCoords[i], (int) ballTrailCoords[i + 1], (int) o.width, (int) o.height);
                            }
                        } else if (ballTrailCoords[i + 2]/16777216 == 1) {
                            //Star trail
                            switch ((ballTrailCoords[i + 2]/65536 /*2^(2*8) = 65536*/) % 128 /*2^8 = 128 -> Getting the contents of the second byte of an int*/) {
                                case YELLOW_STAR:
                                    if (doTrailParticleShrinking) {
                                        g2d.drawImage(yellowStar, (int) ballTrailCoords[i], (int) ballTrailCoords[i + 1], (int) (o.width * ((double) i)/ballTrailCoords.length), (int) (o.height * ((double) i)/ballTrailCoords.length), this);
                                    } else {
                                        g2d.drawImage(yellowStar, (int) ballTrailCoords[i], (int) ballTrailCoords[i + 1], this);
                                    }
                                    break;
                                case GREEN_STAR:
                                    if (doTrailParticleShrinking) {
                                        g2d.drawImage(greenStar, (int) ballTrailCoords[i], (int) ballTrailCoords[i + 1], (int) (o.width * ((double) i)/ballTrailCoords.length), (int) (o.height * ((double) i)/ballTrailCoords.length), this);
                                    } else {
                                        g2d.drawImage(greenStar, (int) ballTrailCoords[i], (int) ballTrailCoords[i + 1], this);
                                    }
                                    break;
                                case BLUE_STAR:
                                    if (doTrailParticleShrinking) {
                                        g2d.drawImage(blueStar, (int) ballTrailCoords[i], (int) ballTrailCoords[i + 1], (int) (o.width * ((double) i)/ballTrailCoords.length), (int) (o.height * ((double) i)/ballTrailCoords.length), this);
                                    } else {
                                        g2d.drawImage(blueStar, (int) ballTrailCoords[i], (int) ballTrailCoords[i + 1], this);
                                    }
                                    break;
                            }
                        }
                    }
                }
                g2d.setColor(o.color);
                g2d.fillOval((int) (oval.x), (int) (oval.y), (int) (oval.width), (int) (oval.height));
            } else if (o instanceof Quadrilateral) {
                Quadrilateral quad = (Quadrilateral) o;
                g2d.fillRect((int) quad.x, (int) quad.y, (int) quad.width, (int) quad.height);
            }
        }
        g2d.setColor(Color.BLACK);
        try {
            for (Player player : Player.getRegisteredPlayers()) {
                if (player.visible) {
                }
                if (player.scoreVisible) {
                    if (player.scoreOppSide) {
                        fm = g2d.getFontMetrics();
                        g2d.drawString(player.name + ": " + player.score, player.scoreX - fm.stringWidth(player.name + ": " + player.score), player.scoreY);
                    } else {
                        g2d.drawString(player.name + ": " + player.score, player.scoreX, player.scoreY);
                    }
                }
            }
        } catch (java.util.ConcurrentModificationException cme) {
            cme.printStackTrace();
        }
        if (System.currentTimeMillis() < this.countdownTimestamp + countdownTime) {
            g2d.setColor(Color.BLACK);
            g2d.fillArc(this.getWidth()/2 - 100, this.getHeight()/2 - 100, 200, 200, 90, -(int) (System.currentTimeMillis()-this.countdownTimestamp)%1000/(1000/360));
            g2d.setColor(Color.BLUE);
            g2d.setFont(new Font("Calibri", Font.PLAIN, 50));
            fm = g2d.getFontMetrics();
            String str = Long.toString((this.countdownTime-System.currentTimeMillis()+this.countdownTimestamp)/1000+1);
            g2d.drawString(str, (this.getWidth() - fm.stringWidth(str))/2, (this.getHeight() + fm.getAscent())/2);
            g2d.setColor(countdownMessageColor);
            g2d.drawString(countdownMessage, (this.getWidth() - fm.stringWidth(countdownMessage))/2, (this.getHeight() - fm.getAscent())/2 - 120);
        }
        if (cinst.paused) {
            g2d.setFont(defaultFont);
            fm = g2d.getFontMetrics();
            g2d.drawString(pausedMessage, (cinst.getWidth() - fm.stringWidth(pausedMessage))/2, (cinst.getHeight() - fm.getAscent())/2);
        }
    }
    public void resetScene(String message, Color color) throws InterruptedException {
        pauseBtn.setEnabled(false);
        for (Player p : Player.getRegisteredPlayers()) {
            p.setY((cinst.getHeight()-p.getHeight())/2);
        }
        gameBall.x = (cinst.getWidth()-gameBall.width)/2;
        gameBall.y = (cinst.getHeight()-gameBall.height)/2;
        if (doBallTrailEffect) {
            for (int i = 0; i < ballTrailCoords.length; i += 3) {
                if (doRandomTrailPositions) {
                    ballTrailCoords[i] = (int) (Math.random() * gameBall.motion[0]);
                    ballTrailCoords[i + 1] = (int) (Math.random() * gameBall.motion[1]);
                    int cachedNum = ballTrailCoords[i];
                    double randomRadian = Math.random() * 2 * Math.PI;
                    ballTrailCoords[i] = (int) (gameBall.x + cachedNum * Math.cos(randomRadian) - ballTrailCoords[i + 1] * Math.sin(randomRadian));
                    ballTrailCoords[i + 1] = (int) (gameBall.y + cachedNum * Math.sin(randomRadian) + ballTrailCoords[i + 1] * Math.cos(randomRadian));
                } else {
                    ballTrailCoords[i] = (int) gameBall.x;
                    ballTrailCoords[i + 1] = (int) gameBall.y;
                }
                if (ballTrailType == BALL_TRAIL) {
                    ballTrailCoords[i + 2] = 0; // Any extra trail data if applicable - 0 means no data - ball by default
                } else if (ballTrailType == STAR_TRAIL) {
                    ballTrailCoords[i + 2] = (1 * 16777216) + ((int) (Math.random() * 3)) * 65536;
                }
            }
        }
        double randomXComponent = (ballSpeed - ballXComponentLowerBound) * Math.random();
        Player.pauseAllPlayers();
        animateCountdown(3, message, color);
        Thread.sleep(3000);
        Player.resumeAllPlayers();
        this.gameBall.motion[0] = (ballXComponentLowerBound + randomXComponent) * Math.signum(Math.random() - 0.5);
        this.gameBall.motion[1] = (ballSpeed - randomXComponent - ballXComponentLowerBound) * Math.signum(Math.random() - 0.5);
        System.out.println("x-motion: " + gameBall.motion[0] + ", y-motion: " + gameBall.motion[1]);
        gameBall.updateCachedMotionData(gameBall);
        pauseBtn.setEnabled(true);
    }
    public void startPlaying(int ballSpeed, int playerSpeed, boolean doAI, boolean randomBallDeflection, Color ballColor) {
        if (doBallTrailEffect) {
            ballTrailCoords = new int[3 * ballTrailAmount];
        }
        try {
            yellowStar = ImageIO.read(getClass().getResource("yellow_star.png"));
            greenStar = ImageIO.read(getClass().getResource("green_star.png"));
            blueStar = ImageIO.read(getClass().getResource("blue_star.png"));
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        frame.getContentPane().removeAll();
        frame.addWindowStateListener(new WindowStateListener() {
            public void windowStateChanged(WindowEvent e) {
                for (Player p : Player.getRegisteredPlayers()) {
                    if (p.side == TemporaryPlayer.RIGHT) {
                        p.setX(cinst.getWidth() - 40);
                        p.scoreX = cinst.getWidth() - 20;
                    }
                }
            }
        });
        frame.addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                for (Player p : Player.getRegisteredPlayers()) {
                    if (p.side == TemporaryPlayer.RIGHT) {
                        p.setX(cinst.getWidth() - 40);
                        p.scoreX = cinst.getWidth() - 20;
                    }
                }
            }
        });
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        JPanel optionsPanel = new JPanel();
        optionsPanel.setLayout(new BorderLayout());
        pauseBtn = new JButton("Pause...");
        pauseBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cinst.requestFocus();
                cinst.paused = !cinst.paused;
                if (!cinst.paused) {
                    pauseBtn.setText("Pause...");
                    new Thread() {
                        public void run() {
                            animateCountdown(3, "Resuming...", Color.BLACK);
                            try {
                                Thread.sleep(3000);
                            } catch (InterruptedException ie) {
                                ie.printStackTrace();
                            }
                            if (!cinst.paused) {
                                Player.resumeAllPlayers();
                            }
                        }
                    }.start();
                } else {
                    pauseBtn.setText("Resume...");
                    Player.pauseAllPlayers();
                }
            }
        });
        frame.getContentPane().add(mainPanel);
        mainPanel.add(optionsPanel, BorderLayout.NORTH);
        mainPanel.add(cinst, BorderLayout.CENTER);
        optionsPanel.add(pauseBtn);
        mainPanel.revalidate();
        mainPanel.repaint();

        
        this.ballSpeed = ballSpeed;
        this.playingWithAI = doAI;
        this.randomBallDeflection = randomBallDeflection;
        this.gameBall = new Oval(this.getWidth()/2 - ballRadius, this.getHeight()/2 - ballRadius, 2*ballRadius, 2*ballRadius, ballColor);
        //Realistic energy absorption:
        //this.gameBall.velocityChangeOnCollision = 0.5f;
        this.gameBall.ignoreGravity = !quadraticBallMotion;
        TemporaryPlayer currentTemplate;
        Player.playerSpeed = playerSpeed;
        for (int i = 0; i < TemporaryPlayer.getRegisteredTemplates().size(); i++) {
            currentTemplate = TemporaryPlayer.getRegisteredTemplates().get(i);
            currentTemplate.playerSide = i;
            currentTemplate.createPlayer();
        }
        if (doAI) {
            FontMetrics fm = Toolkit.getDefaultToolkit().getFontMetrics(defaultFont);
            AIPlayer = new Player(new Quadrilateral(this.getWidth() - 40, this.getHeight()/2 - 50, 20, 100, new Color(0, 255, 255)), 0, "Larry the AI", cinst, new HashMap<KeyStroke, Integer>(), cinst.getWidth() - 20, 20, true, TemporaryPlayer.RIGHT);
        }
        Thread graphicsThread = new Thread() {
            @Override
            public void run() {
                FontMetrics fm;
                int sWidth;
                fm = Toolkit.getDefaultToolkit().getFontMetrics(defaultFont);
                try {
                    while (true) {
                        /*for (PhysicalObject o : PhysicalObject.getRegisteredObjects()) {
                            cinst.repaint((int) o.x, (int) o.y, (int) o.width, (int) o.height);
                        }
                        for (Player p : Player.getRegisteredPlayers()) {
                            if (p.scoreOppSide) {
                                sWidth = fm.stringWidth(p.name + ": " + p.score);
                                cinst.repaint((int) (p.scoreX - sWidth), (int) p.scoreY, sWidth, fm.getAscent());
                            } else {
                                cinst.repaint((int) p.scoreX - fm.stringWidth(p.name + ": " + p.score), (int) p.scoreY, fm.stringWidth(p.name + ": " + p.score), fm.getAscent());
                            }
                        }*/
                        cinst.repaint();
                        Thread.sleep((long) (1.0/fps * 1000));
                    }
                } catch (InterruptedException ie) {
                    ie.printStackTrace();
                }
                System.out.println("Graphics thread finished");
            }
        };
        graphicsThread.start();
        Thread physicsThread = new Thread() {
            double[] tempArr;
            double randomXComponent;
            @Override
            public void run() {
                try {
                    while (true) {
                        if (!Player.areAllPlayersPaused()) {
                            for (PhysicalObject o : PhysicalObject.getRegisteredObjects()) {
                                o.x += o.motion[0];
                                o.y += o.motion[1];
                                tempArr = o.motion;
                                if (!(tempArr[0] == 0 && tempArr[1] == 0)) {
                                    o.motion[0] += (o.acceleration/fps) * Math.atan(tempArr[1]/tempArr[0]) * (180/Math.PI)/90;
                                    if (o.ignoreGravity) {
                                        o.motion[1] += (o.acceleration/fps) * (90 - Math.atan(tempArr[1]/tempArr[0]) * (180/Math.PI))/90;
                                    } else {
                                        o.motion[1] += (o.acceleration/fps) * (90 - Math.atan(tempArr[1]/tempArr[0]) * (180/Math.PI))/90 + gravity/fps;
                                    }
                                }
                                if (o == gameBall) {
                                    if (o.x <= 0) {
                                        o.x = 0;
                                        Player.getRegisteredPlayers().get(1).score++;
                                        resetScene("", Color.BLACK);
                                    } else if (o.x + o.width >= getWidth()) {
                                        o.x = cinst.getWidth() - o.width;
                                        Player.getRegisteredPlayers().get(0).score++;
                                        resetScene("", Color.BLACK);
                                    } else if (o.y <= 0) {
                                        o.y = 0;
                                        o.motion[1] = Math.abs(o.motion[1]) * (1-o.velocityChangeOnCollision);
                                    } else if (o.y + o.height >= getHeight()) {
                                        o.y = getHeight() - o.height;
                                        o.motion[1] = -Math.abs(o.motion[1]) * (1-o.velocityChangeOnCollision);
                                    }
                                    for (Player p : Player.getRegisteredPlayers()) {
                                        switch (o.getCollisionData(p.getPlayerObject())) {
                                            case PhysicalObject.TOP:
                                                if (cinst.randomBallDeflection) {
                                                    randomXComponent = (ballSpeed - ballXComponentLowerBound) * Math.random();
                                                    o.motion[0] = (ballXComponentLowerBound + randomXComponent) * Math.signum(-o.motion[0]);
                                                    o.motion[1] = (ballSpeed - randomXComponent - ballXComponentLowerBound) * Math.signum(-o.motion[1]);
                                                } else {
                                                    o.motion[1] = -o.motion[1];
                                                }
                                                o.y = p.getPlayerObject().y - o.height;
                                                gameBall.updateCachedMotionData(gameBall);
                                                break;
                                            case PhysicalObject.RIGHT:
                                                if (cinst.randomBallDeflection) {
                                                    randomXComponent = (ballSpeed - ballXComponentLowerBound) * Math.random();
                                                    o.motion[0] = (ballXComponentLowerBound + randomXComponent) * Math.signum(-o.motion[0]);
                                                    o.motion[1] = (ballSpeed - randomXComponent - ballXComponentLowerBound) * Math.signum(-o.motion[1]);
                                                } else {
                                                    o.motion[0] = -o.motion[0];
                                                }
                                                o.x = p.getPlayerObject().x + p.getPlayerObject().width;
                                                gameBall.updateCachedMotionData(gameBall);
                                                break;
                                            case PhysicalObject.BOTTOM:
                                                if (cinst.randomBallDeflection) {
                                                    randomXComponent = (ballSpeed - ballXComponentLowerBound) * Math.random();
                                                    o.motion[0] = (ballXComponentLowerBound + randomXComponent) * Math.signum(-o.motion[0]);
                                                    o.motion[1] = (ballSpeed - randomXComponent - ballXComponentLowerBound) * Math.signum(-o.motion[1]);
                                                } else {
                                                    o.motion[1] = -o.motion[1];
                                                }
                                                o.y = p.getPlayerObject().y + p.getPlayerObject().height;
                                                gameBall.updateCachedMotionData(gameBall);
                                                break;
                                            case PhysicalObject.LEFT:
                                                if (cinst.randomBallDeflection) {
                                                    randomXComponent = (ballSpeed - ballXComponentLowerBound) * Math.random();
                                                    o.motion[0] = (ballXComponentLowerBound + randomXComponent) * Math.signum(-o.motion[0]);
                                                    o.motion[1] = (ballSpeed - randomXComponent - ballXComponentLowerBound) * Math.signum(-o.motion[1]);
                                                } else {
                                                    o.motion[0] = -o.motion[0];
                                                }
                                                o.x = p.getPlayerObject().x - o.width;
                                                gameBall.updateCachedMotionData(gameBall);
                                                break;
                                        }
                                    }
                                }
                            }
                            if (playingWithAI && !Player.areAllPlayersPaused()) {
                                AIAction(AIPlayer);
                            }
                            if (doBallTrailEffect) {
                                //Array shift and draw ball blurs
                                for (int i = 3; i < ballTrailCoords.length; i++) {
                                    ballTrailCoords[i-3] = ballTrailCoords[i];
                                }
                                if (doRandomTrailPositions) {
                                    ballTrailCoords[ballTrailCoords.length - 3] = (int) (Math.random() * gameBall.motion[0]);
                                    ballTrailCoords[ballTrailCoords.length - 2] = (int) (Math.random() * gameBall.motion[1]);
                                    int cachedNum = ballTrailCoords[ballTrailCoords.length - 3];
                                    double randomRadian = Math.random() * 2 * Math.PI;
                                    ballTrailCoords[ballTrailCoords.length - 3] = (int) (gameBall.x + cachedNum * Math.cos(randomRadian) - ballTrailCoords[ballTrailCoords.length - 2] * Math.sin(randomRadian));
                                    ballTrailCoords[ballTrailCoords.length - 2] = (int) (gameBall.y + cachedNum * Math.sin(randomRadian) + ballTrailCoords[ballTrailCoords.length - 2] * Math.cos(randomRadian));
                                } else {
                                    ballTrailCoords[ballTrailCoords.length - 3] = (int) gameBall.x;
                                    ballTrailCoords[ballTrailCoords.length - 2] = (int) gameBall.y;
                                }
                                if (ballTrailType == BALL_TRAIL) {
                                    ballTrailCoords[ballTrailCoords.length - 1] = 0;
                                } else if (ballTrailType == STAR_TRAIL) {
                                    ballTrailCoords[ballTrailCoords.length - 1] = (1 * 16777216) + ((int) (Math.random() * 3)) * 65536;
                                }
                            }
                        }
                        if (autoResetScene && Math.abs(gameBall.motion[0]) <= ballXComponentLowerBound && !Player.areAllPlayersPaused()) {
                            resetScene("Ball stuck/too slow!", Color.RED);
                        }
                        Thread.sleep((long) (1.0/fps * 1000));
                    }
                } catch (InterruptedException ie) {
                    ie.printStackTrace();
                }
                System.out.println("Physics thread finished");
            }
        };
        Thread playerThread = new Thread() {
            @Override
            public void run() {
                Player currentPlayer;
                try {
                    while (true) {
                        for (int i = 0; i < Player.getRegisteredPlayers().size(); i++) {
                            currentPlayer = Player.getRegisteredPlayers().get(i);
                            switch (currentPlayer.currentAction) {
                                case Player.UP:
                                    if (currentPlayer.getY() >= 5 && !Player.areAllPlayersPaused()) {
                                        currentPlayer.setY(Math.max(currentPlayer.getY() - Player.playerSpeed, 5));
                                    }
                                    break;
                                case Player.DOWN:
                                    if (currentPlayer.getY() + currentPlayer.getHeight() <= currentPlayer.panel.getHeight() - 5 && !Player.areAllPlayersPaused()) {
                                        currentPlayer.setY(Math.min(currentPlayer.getY() + Player.playerSpeed, currentPlayer.panel.getHeight() - currentPlayer.getHeight() - 5));
                                    }
                                    break;
                                case Player.NONE:
                                    break;
                                default:
                            }
                            //System.out.println(currentPlayer.currentAction + ", " + currentPlayer.getPlayerObject().motion[1]);
                        }
                        Thread.sleep((long) (1.0/fps * 1000));
                    }
                } catch (InterruptedException ie) {
                    ie.printStackTrace();
                }
                System.out.println("Player action handler thread finished");
            }
        };
        playerThread.start();
        frame.removeWindowListener(currentWindowListener);
        currentWindowListener = new WindowListener() {
            public void windowDeactivated(WindowEvent e) {
            }
            public void windowActivated(WindowEvent e) {
            }
            public void windowDeiconified(WindowEvent e) {
            }
            public void windowIconified(WindowEvent e) {
            }
            public void windowClosed(WindowEvent e) {
            }
            public void windowClosing(WindowEvent e) {
                //Free all resources
                physicsThread.interrupt();
                playerThread.interrupt();
                graphicsThread.interrupt();
                if (tempFrame != null) {
                    tempFrame.dispose();
                }
                frame.dispose();
            }
            public void windowOpened(WindowEvent e) {
            }
        };
        frame.addWindowListener(currentWindowListener);
        try {
            resetScene("", Color.BLACK);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }
        //Start physics thread AFTER game ball position is set, to avoid the player on the other side getting a free point
        physicsThread.start();
    }
    public void animateCountdown(int seconds, String countdownMessage, Color countdownMessageColor) {
        this.countdownTimestamp = System.currentTimeMillis();
        this.countdownTime = seconds * 1000;
        this.countdownMessage = countdownMessage;
        this.countdownMessageColor = countdownMessageColor;
    }
    public void AIAction(Player AIPlayer) {
        //Number of oscillations to ignore
        //System.out.println(/*gameBall.x - frame.getWidth()/(Math.abs(gameBall.motion[0]/gameBall.motion[1]) * frame.getHeight())*/ bottomXLineToEnd(gameBall.motion[1]/gameBall.motion[0], frame.getWidth(), frame.getHeight(), gameBall.x, gameBall.y));
        switch (gameAIIntelligenceLevel) {
            case AI_STUPID:
                
                break;
            case AI_TYPICAL:
                //Blindly chase the ball's y-component
                if (gameBall.y + gameBall.height/2 > AIPlayer.getY() + AIPlayer.getHeight()/2) {
                    AIPlayer.setY(Math.max(AIPlayer.getY() + Player.playerSpeed, 5));
                } else if (gameBall.y + gameBall.height < AIPlayer.getY() + AIPlayer.getHeight()/2) {
                    AIPlayer.setY(Math.min(AIPlayer.getY() - Player.playerSpeed, cinst.getHeight() - 5 - AIPlayer.getHeight()));
                }
                break;
            case AI_VECTOR:
                double[] ballCoords = new double[] {gameBall.x, gameBall.y};
                double[] ballMotion = new double[] {gameBall.motion[0], gameBall.motion[1]};
                while (true) {
                    ballCoords[0] += ballMotion[0];
                    ballCoords[1] += ballMotion[1];
                    if (!(ballMotion[0] == 0 && ballMotion[1] == 0)) {
                        ballMotion[0] += (gameBall.acceleration/fps) * (Math.atan(ballMotion[1]/ballMotion[0]) * (180/Math.PI))/90;
                        if (gameBall.ignoreGravity) {
                            ballMotion[1] += (gameBall.acceleration/fps) * (90 - Math.atan(ballMotion[1]/ballMotion[0]) * (180/Math.PI))/90 + gravity/fps;
                        } else {
                            ballMotion[1] += (gameBall.acceleration/fps) * (90 - Math.atan(ballMotion[1]/ballMotion[0]) * (180/Math.PI))/90 + gravity/fps;
                        }
                    }
                    if (ballCoords[1] + gameBall.height >= getHeight()) {
                        ballCoords[1] = getHeight() - gameBall.height;
                        ballMotion[1] = -Math.abs(ballMotion[1]) * (1.0f - gameBall.velocityChangeOnCollision);
                    } else if (ballCoords[1] <= 0) {
                        ballCoords[1] = 0;
                        ballMotion[1] = Math.abs(ballMotion[1]) * (1.0f - gameBall.velocityChangeOnCollision);
                    }
                    if (ballMotion[0] < 0 && ballCoords[0] <= Player.getRegisteredPlayers().get(0).getX() + Player.getRegisteredPlayers().get(0).getWidth()) {
                        break;
                    } else if (ballMotion[0] > 0 && ballCoords[0] + gameBall.width >= Player.getRegisteredPlayers().get(1).getX()) {
                        break;
                    }
                }
                if (ballCoords[1] + gameBall.height/2 > AIPlayer.getY() + AIPlayer.getHeight()/2) {
                    AIPlayer.setY(Math.max(AIPlayer.getY() + Player.playerSpeed, 5));
                } else if (ballCoords[1] + gameBall.height < AIPlayer.getY() + AIPlayer.getHeight()/2) {
                    AIPlayer.setY(Math.min(AIPlayer.getY() - Player.playerSpeed, cinst.getHeight() - 5 - AIPlayer.getHeight()));
                }
                //Get the accessible width
                //AAAAAAAAAAAAAAARRRRRRRRRRRRRRRRGGGGGGGGGGGGGHHHHHHHHHHHHHHHHH!!!
                /*double width = Player.getRegisteredPlayers().get(1).getPlayerObject().x - Player.getRegisteredPlayers().get(0).getPlayerObject().x - Player.getRegisteredPlayers().get(0).getPlayerObject().width - gameBall.width;
                //Get an array of doubles with two indices, representing the x of the line which touches the other side's edge and the number of collisions with the (top and bottom) edges, respectively
                double[] lastXHitData = bottomXLineToEnd(gameBall, width, getHeight() - gameBall.height);
                //Declare variable storing width of ball's incomplete cycle (bottom to top = full 'cycle', so to speak)
                double incompleteCycleX;
                //Declare variabe storing width of complete ball cycle, based on x and y components and height of the game window
                double cycleWidth = Math.abs(gameBall.motion[0]/gameBall.motion[1]) * (getHeight() - gameBall.height);
                //Check whether number of collisions is odd
                int isOdd;
                if (gameBall.cachedMotion[1] > 0) {
                    incompleteCycleX = Math.abs(gameBall.motion[0]/gameBall.motion[1]) * (getHeight() - gameBall.height - gameBall.cachedCoords[1] - gameBall.width);
                    //System.out.println("Gradient: " + 1/dxdy + ", height to cover: " + (height - obj.cachedCoords[1] - obj.height) + ", incompleteCycleWidth: " + incompleteCycleX);
                } else {
                    incompleteCycleX = Math.abs(gameBall.motion[0]/gameBall.motion[1]) * (gameBall.cachedCoords[1]);
                    //System.out.println("Gradient: " + 1/dxdy + ", height to cover: " + obj.cachedCoords[1] + ", incompleteCycleWidth: " + incompleteCycleX);
                }
                if (gameBall.motion[0] < 0) {
                    System.out.println(lastXHitData[1] + " collisions, x-drop; width:" + width);
                    isOdd = (int) lastXHitData[1] % 2;
                } else {
                    System.out.println(lastXHitData[1] + " collisions, x-rise; width:" + width);
                    isOdd = (int) lastXHitData[1] % 2;
                }
                //System.out.println(lastXHitData[0] * Math.abs(gameBall.motion[1]/gameBall.motion[0]) + ", " + isOdd);
                System.out.println(getHeight() + ", " + lastXHitData[0] + ", " + (width-lastXHitData[0]) * Math.abs(gameBall.motion[1]/gameBall.motion[0]));
                if (isOdd == 0) {
                    //Same gradient
                    //System.out.println("Same gradient: " + gameBall.cachedMotion[1]/gameBall.cachedMotion[0] + " compared to " + gameBall.motion[1]/gameBall.motion[0]);
                    if (AIPlayer.getY() < getHeight()/2*(Math.signum(gameBall.cachedMotion[1]) + 1) + Math.signum(gameBall.cachedMotion[0]) * (width-lastXHitData[0]) * Math.abs(gameBall.motion[1]/gameBall.motion[0])) {
                        if (AIPlayer.getY() + AIPlayer.getHeight() < getHeight()) {
                            AIPlayer.setY(AIPlayer.getY() + Player.playerSpeed);
                        }
                    } else {
                        if (AIPlayer.getY() > 0) {
                            AIPlayer.setY(AIPlayer.getY() - Player.playerSpeed);
                        }
                    }
                } else {
                    //Opposite gradient - other side (y-axis)
                    //System.out.println("Opposite gradient: " + gameBall.cachedMotion[1]/gameBall.cachedMotion[0] + " compared to " + gameBall.motion[1]/gameBall.motion[0]);
                    if (AIPlayer.getY() < getHeight()/2*(Math.signum(-gameBall.cachedMotion[1]) + 1) - Math.signum(gameBall.cachedMotion[0]) * (width-lastXHitData[0]) * Math.abs(gameBall.motion[1]/gameBall.motion[0])) {
                        if (AIPlayer.getY() + AIPlayer.getHeight() < getHeight()) {
                            AIPlayer.setY(AIPlayer.getY() + Player.playerSpeed);
                        }
                    } else {
                        if (AIPlayer.getY() > 0) {
                            AIPlayer.setY(AIPlayer.getY() - Player.playerSpeed);
                        }
                    }
                }*/

                break;
            default:
        }
    }
    /*public double[] bottomXLineToEnd(PhysicalObject obj, double width, double height) {
        double dxdy = obj.cachedMotion[0]/Math.abs(obj.cachedMotion[1]);
        double cycleWidth = Math.abs(height*dxdy);
        double incompleteCycleX;
        //System.out.println(obj.cachedMotion[0] + ", " + obj.cachedMotion[1] + ", " + obj.motion[0] + ", " + obj.motion[1] + ", " + dxdy);
        if (obj.cachedMotion[1] > 0) {
            incompleteCycleX = Math.abs(dxdy) * (height - obj.cachedCoords[1] - obj.width);
        } else {
            incompleteCycleX = Math.abs(dxdy) * (obj.cachedCoords[1]);
        }
        if (obj.cachedMotion[0] > 0) {
            //g2d.drawLine((int) obj.cachedCoords[0], (int) obj.cachedCoords[1], (int) (obj.cachedCoords[0] + incompleteCycleX), (int) (height/2 * (1 + Math.signum(obj.cachedMotion[1]))));
            //for (int i = 0; i < Math.ceil((width - obj.cachedCoords[0] - incompleteCycleX) / cycleWidth); i++) {
            //    g2d.drawLine((int) (obj.cachedCoords[0] + incompleteCycleX + (cycleWidth * i)), (int) (height * Math.signum(i % 2)), (int) (obj.cachedCoords[0] + incompleteCycleX + (cycleWidth * (i + 1))), (int) (height * Math.signum((i + 1) % 2)));
            //}
            return new double[] {obj.cachedCoords[0] + incompleteCycleX + Math.floor((width - obj.cachedCoords[0] - incompleteCycleX) / cycleWidth) * cycleWidth, Math.floor((width - obj.cachedCoords[0] - incompleteCycleX) / cycleWidth) + 1};// + Math.floor((width + offsetX - obj.cachedCoords[0])/cycleWidth) * cycleWidth);// + Math.floor((width - obj.cachedCoords[0])/cycleWidth) * cycleWidth);
        } else {
            //g2d.drawLine((int) obj.cachedCoords[0], (int) obj.cachedCoords[1], (int) (obj.cachedCoords[0] - incompleteCycleX), (int) (height/2 * (1 + Math.signum(obj.cachedMotion[1]))));
            //for (int i = 0; i < (obj.cachedCoords[0] - incompleteCycleX) / cycleWidth; i++) {
            //    g2d.drawLine((int) (obj.cachedCoords[0] - incompleteCycleX - (cycleWidth * i)), (int) (height * Math.signum(i % 2)), (int) (obj.cachedCoords[0] - incompleteCycleX - (cycleWidth * (i + 1))), (int) (height * Math.signum((i + 1) % 2)));
            //}
            return new double[] {obj.cachedCoords[0] - incompleteCycleX - Math.floor((obj.cachedCoords[0] - incompleteCycleX) / cycleWidth) * cycleWidth, Math.floor((obj.cachedCoords[0] - incompleteCycleX) / cycleWidth) + 1};// + Math.floor((obj.cachedCoords[0] - offsetX)/cycleWidth) * cycleWidth);// + Math.floor(obj.cachedCoords[0]/cycleWidth) * cycleWidth);
        }
    }*/
}
class ComboItem<T> {
    String text;
    T value;
    public ComboItem(String text, T value) {
        this.text = text;
        this.value = value;
    }
    @Override
    public String toString() {
        return text;
    }
    @Override
    public int hashCode() {
        return this.value.toString().hashCode();
    }
    public boolean equals(Object o) {
        try {
            if (this.value.toString().hashCode() == ((ComboItem) o).value.toString().hashCode()) {
                return true;
            } else {
                return false;
            }
        } catch (ClassCastException cce) {
            return false;
        }
    }
}
abstract class PhysicalObject {
    public static final int NONE = -1, TOP = 0, RIGHT = 1, BOTTOM = 2, LEFT = 3;
    private static LinkedList<PhysicalObject> registeredObjects = new LinkedList<PhysicalObject>();
    double x, y, width, height;
    double[] cachedCoords = new double[2];
    double[] cachedMotion = new double[2];
    double[] motion = new double[] {0, 0};
    double acceleration = 0;
    float velocityChangeOnCollision = 0f;
    boolean ignoreGravity = true;
    Color color;
    public PhysicalObject(double x, double y, double width, double height, Color color) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = color;
        registeredObjects.add(this);
    }
    public static LinkedList<PhysicalObject> getRegisteredObjects() {
        return registeredObjects;
    }
    public void updateCachedMotionData(PhysicalObject object) {
        this.cachedCoords[0] = object.x;
        this.cachedCoords[1] = object.y;
        this.cachedMotion[0] = object.motion[0];
        this.cachedMotion[1] = object.motion[1];
    }
    public void remove() {
        registeredObjects.remove(this);
    }
    public boolean isInTile() {
        return false;
    }
    public int[] getTileLocations() {
        int[] tileLocations = new int[] {};
        return tileLocations;
    }
    public boolean isTouching(PhysicalObject entity) {
        return (entity.x < this.x + this.width && this.x < entity.x + entity.width) &&
               (entity.y < this.y + this.height && this.y < entity.y + entity.height);
    }
    public int getCollisionData(PhysicalObject entity) {
        //Array with x and y components of net motion in the entity parameter's perspective
        double[] netMotionWRTEntity = {this.motion[0] - entity.motion[0], this.motion[1] - entity.motion[1]};
        if (this.isTouching(entity)) {
            if (entity.x < this.x + this.width && netMotionWRTEntity[0] < 0) {
                return PhysicalObject.RIGHT;
            } else if (this.x < entity.x + entity.width && netMotionWRTEntity[0] > 0) {
                return PhysicalObject.LEFT;
            } else if (entity.y < this.y + this.height && netMotionWRTEntity[1] > 0) {
                return PhysicalObject.BOTTOM;
            } else if (this.y < entity.y + entity.height && netMotionWRTEntity[1] < 0) {
                return PhysicalObject.TOP;
            } else {
                return PhysicalObject.NONE;
            }
        } else {
            return PhysicalObject.NONE;
        }
    }
}
class Oval extends PhysicalObject {
    public Oval(double x, double y, double width, double height, Color color) {
        super(x, y, width, height, color);
    }
    public boolean isTouching(Oval entity) {
        if (super.isTouching(entity)) {
            return true;
        } else {
            return false;
        }
    }
}
class Quadrilateral extends PhysicalObject {
    public Quadrilateral(double x, double y, double width, double height, Color color) {
        super(x, y, width, height, color);
    }
}
class Player {
    public static double playerSpeed = 0;
    public static final int NONE = -1, UP = 0, DOWN = 1;
    private static LinkedList<Player> registeredPlayers = new LinkedList<Player>();
    private static Boolean allPlayersPaused = false;
    private PhysicalObject playerObj;
    private Player thisPlayer = this;
    int currentAction = Player.NONE;
    PingPongGame panel;
    AbstractAction upAction = new AbstractAction() {
        public void actionPerformed(ActionEvent e) {
            thisPlayer.currentAction = Player.UP;
        }
    }, downAction = new AbstractAction() {
        public void actionPerformed(ActionEvent e) {
            thisPlayer.currentAction = Player.DOWN;
        }
    }, releaseAction = new AbstractAction() {
        public void actionPerformed(ActionEvent e) {
            thisPlayer.currentAction = Player.NONE;
        }
    };
    boolean visible = true, scoreVisible = true, scoreOppSide;
    int score, scoreX, scoreY, side;
    private static int i = 0;
    private final Object o = new Object();
    private LinkedList<Integer> ownedBindingIds = new LinkedList<Integer>();
    String name;
    HashMap<KeyStroke, AbstractAction> bindings;
    public PhysicalObject getPlayerObject() {
        return playerObj;
    }
    public void setX(double x) {
        this.playerObj.x = x;
    }
    public void setY(double y) {
        this.playerObj.y = y;
    }
    public double getX() {
        return this.playerObj.x;
    }
    public double getY() {
        return this.playerObj.y;
    }
    public void setWidth(double width) {
        this.playerObj.width = width;
    }
    public void setHeight(double height) {
        this.playerObj.height = height;
    }
    public double getWidth() {
        return this.playerObj.width;
    }
    public double getHeight() {
        return this.playerObj.height;
    }
    public static void pauseAllPlayers() {
        synchronized (allPlayersPaused) {
            allPlayersPaused = true;
        }
    }
    public static void resumeAllPlayers() {
        synchronized (allPlayersPaused) {
            allPlayersPaused = false;
        }
    }
    public synchronized static boolean areAllPlayersPaused() {
        return allPlayersPaused;
    }
    public Player(PhysicalObject playerObj, int score, String name, PingPongGame panel, HashMap<KeyStroke, Integer> bindings, int scoreX, int scoreY, boolean scoreOppSide, int side) {
        this.playerObj = playerObj;
        this.score = score;
        this.name = name;
        this.panel = panel;
        this.scoreX = scoreX;
        this.scoreY = scoreY;
        this.scoreOppSide = scoreOppSide;
        this.side = side;
        HashMap<KeyStroke, AbstractAction> newMap = new HashMap<KeyStroke, AbstractAction>();
        for (KeyStroke binding : bindings.keySet()) {
            if (bindings.get(binding) == Player.UP) {
                newMap.put(binding, upAction);
            } else if (bindings.get(binding) == Player.DOWN) {
                newMap.put(binding, downAction);
            }
        }
        this.bindings = newMap;
        for (KeyStroke value : this.bindings.keySet()) {
            this.panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(value, i);
            this.panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(value.getKeyCode(), 0, true), o);
            this.panel.getActionMap().put(i, this.bindings.get(value));
            ownedBindingIds.add(i);
            i++;
        }
            
        this.panel.getActionMap().put(o, releaseAction);
        synchronized (registeredPlayers) {
            registeredPlayers.add(this);
        }
        /*this.panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0), "right");
        this.panel.getActionMap().put("right", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                playerObj.x += 1;
            }
        });
        this.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0), "left");
        this.getActionMap().put("left", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                mainOval.x -= 1;
            }
        });
        this.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "up");
        this.getActionMap().put("up", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                mainOval.y -= 1;
            }
        });
        this.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), "down");
        this.getActionMap().put("down", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                mainOval.y += 1;
            }
        });*/
    }
    public void remove() {
        javax.swing.InputMap inputMap = this.panel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        for (int i : ownedBindingIds) {
            this.panel.getActionMap().remove(i);
            i++;
        }
        for (KeyStroke value : this.bindings.keySet()) {
            inputMap.remove(value);
            inputMap.remove(KeyStroke.getKeyStroke(value.getKeyCode(), 0, true));
        }
        this.panel.getActionMap().remove(o);
        registeredPlayers.remove(this);
        playerObj.remove();
    }
    public static LinkedList<Player> getRegisteredPlayers() {
        return registeredPlayers;
    }
}
class TemporaryPlayer {
    public static final int LEFT = 0, RIGHT = 1;
    private static LinkedList<TemporaryPlayer> registeredTemplates = new LinkedList<TemporaryPlayer>();
    int playerSide;
    String name;
    PingPongGame inst;
    HashMap<KeyStroke, Integer> bindings;
    Color color;
    private boolean alreadyConvertedToPlayer = false;
    JPanel indicatorPanel;
    public TemporaryPlayer(String name, HashMap<KeyStroke, Integer> bindings, Color color, PingPongGame inst) {
        this.name = name;
        this.bindings = bindings;
        this.color = color;
        this.inst = inst;
        registeredTemplates.add(this);
    }
    public static LinkedList<TemporaryPlayer> getRegisteredTemplates() {
        return registeredTemplates;
    }
    public void remove() {
        registeredTemplates.remove(this);
    }
    public Player createPlayer() throws IllegalStateException {
        if (alreadyConvertedToPlayer) {
            throw new IllegalStateException("Cannot re-create a player from the same player template");
        } else {
            alreadyConvertedToPlayer = true;
            if (playerSide == TemporaryPlayer.LEFT) {
                return new Player(new Quadrilateral(20, 40, 20, 100, color), 0, name, inst, bindings, 20, 20, false, TemporaryPlayer.LEFT);
            } else if (playerSide == TemporaryPlayer.RIGHT) {
                FontMetrics fm = Toolkit.getDefaultToolkit().getFontMetrics(inst.defaultFont);
                return new Player(new Quadrilateral(inst.getWidth() - 40, inst.getHeight()/2 - 50, 20, 100, color), 0, name, inst, bindings, inst.getWidth() - 20, 20, true, TemporaryPlayer.RIGHT);
            }
        }
        return null;
    }
}
class Counter {
    private static LinkedList<Counter> registeredCounters = new LinkedList<Counter>();
    String key;
    String value;
    Color color;
    Font font;
    double x, y;
    public Counter(double x, double y, String key, String value, Color color, Font font) {
        this.x = x;
        this.y = y;
        this.key = key;
        this.value = value;
        this.color = color;
        this.font = font;
        registeredCounters.add(this);
    }
    public void remove() {
        registeredCounters.remove(this);
    }
    public static LinkedList<Counter> getRegisteredCounters() {
        return registeredCounters;
    }
}
enum MenuResponseStates {
    PENDING_RESPONSE,
    OK,
    CANCEL
}